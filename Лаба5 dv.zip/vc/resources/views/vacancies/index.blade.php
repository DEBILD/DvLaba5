@extends('layout.app')
@section('content')
<style type="text/css">
   body { background: navy !important;color:white; } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */
</style>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Вакансии</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('vacancies.create') }}"> Создать новую вакансию</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>Заголовок</th>
            <th>Название компании</th>
            <th>Описание</th>
            <th>Минимальная зарплата</th>
            <th>Максимальная зарплата</th>
        </tr>
        @foreach ($vacancies as $vacancy)
            <tr>
                <td>{{ $vacancy->title }}</td>
                <td>{{ $vacancy->company_name }}</td>                
                <td>{{ $vacancy->description }}</td>
                <td>{{ $vacancy->salary_min }}</td>
                <td>{{ $vacancy->salary_max }}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('vacancies.show', $vacancy->id) }}">Детали вакансии</a>
                    <a class="btn btn-primary" href="{{ route('vacancies.edit', $vacancy->id) }}">Изменить</a>
                    <form action="{{ route('vacancies.destroy', $vacancy->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Удалить</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>

@endsection
