@extends('layout.app')
@section('content')
<style type="text/css">
   body { background: navy !important;color:white; } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */
</style>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Добавить новую вакансию</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('vacancies.index') }}"> Назад</a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('vacancies.store') }}" method="POST">
        @csrf

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Заголовок:</strong>
                    <input type="text" name="title" class="form-control" placeholder="Заголовок">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Название компании:</strong>
                    <input type="text" name="company_name" class="form-control" placeholder="Название компании">
                </div>
            </div>

            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <strong>Минимальная зарплата:</strong>
                    <input type="text" name="salary_min" class="form-control" placeholder="Минимальная зарплата">
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <strong>Максимальная зарплата:</strong>
                    <input type="text" name="salary_max" class="form-control" placeholder="Максимальная зарплата">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Описание:</strong>
                    <textarea class="form-control" style="height:150px" name="description" placeholder="Описание"></textarea>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Выставить!</button>
            </div>
        </div>
    </form>
@endsection
