@extends('layout.app')
@section('content')
<style type="text/css">
   body { background: navy !important;color:white; } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */
</style>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Информация по вакансии</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('vacancies.index') }}"> Назад</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Заголовок:</strong>
                {{ $vacancy->title }}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Название компании:</strong>
                {{ $vacancy->company_name }}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Описания:</strong>
                {{ $vacancy->description }}
            </div>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <strong>Минимальная зарплата:</strong>
                {{ $vacancy->salary_min }}
            </div>
        </div>

        <div class="col-xs-6 col-sm-6 col-md-6">
            <div class="form-group">
                <strong>Максимальная зарплата:</strong>
                {{ $vacancy->salary_max }}
            </div>
        </div>

    </div>
@endsection
